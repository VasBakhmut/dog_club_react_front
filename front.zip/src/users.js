export const users = [
	{
		Name: 'Vasyl',
		login: 'admin',
		pass: 'admin',
		street: '14 Graham road',
		country: 'Australia',
		postcode: '3190',
		email: 'vas@gmail.com',
	},
	{
		Name: 'Mila',
		login: 'admin1',
		pass: 'admin1',
		street: '14 Graham road',
		country: 'Australia',
		postcode: '3190',
		email: 'mila@gmail.com',
	},
	{
		Name: 'Zara',
		login: 'admin2',
		pass: 'admin2',
		street: '14 Graham road',
		country: 'Australia',
		postcode: '3190',
		email: 'zara@gmail.com',
	},
]
